/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       dylan                                                     */
/*    Created:      Mon Aug 28 2023                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// LeftTop              motor         2               
// RightTop             motor         5               
// Wing                 digital_out   A               
// catapult             motor         4               
// Rightback            motor         10              
// LeftBack             motor         3               
// RightFront           motor         1               
// LeftFront            motor         20              
// Intake               motor         9               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  while(true){

  catapult.setStopping(hold);
//  LeftTop.setStopping(brake);
//  RightTop.setStopping(brake);



  LeftTop.spin(forward,Controller1.Axis3.position(percent), pct);
  LeftBack.spin(forward,Controller1.Axis3.position(percent), pct);
  LeftFront.spin(forward,Controller1.Axis3.position(percent), pct);


  RightTop.spin(forward,Controller1.Axis2.position(percent), pct);
  RightFront.spin(forward,Controller1.Axis2.position(percent), pct);
  Rightback.spin(forward,Controller1.Axis2.position(percent), pct);




  if(Controller1.ButtonA.pressing()){
    Wing.set(true);

  }

 if(Controller1.ButtonB.pressing()){
  Wing.set(false);
}


if(Controller1.ButtonY.pressing()){
LeftTop.spin(forward,100,percent);
RightTop.spin(forward,100,percent);
}

if(Controller1.ButtonX.pressing()){
LeftTop.spin(reverse,100,percent);
RightTop.spin(reverse,100,percent);
}



if(Controller1.ButtonR1.pressing()){
catapult.spin(forward,50, percent);
}
if(Controller1.ButtonR1.pressing()){
catapult.spin(forward,100, percent);
}

else {
catapult.stop();
}



if(Controller1.ButtonL1.pressing()){
Intake.spin(forward,100, percent);
  }

else if(Controller1.ButtonL2.pressing()){
Intake.spin(reverse,100, percent);
  }

else{
Intake.stop();
  }


  }
  wait(20,msec);
}



