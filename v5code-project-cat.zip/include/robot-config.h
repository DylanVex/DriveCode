using namespace vex;

extern brain Brain;

// VEXcode devices
extern controller Controller1;
extern motor LeftTop;
extern motor RightTop;
extern digital_out Wing;
extern motor catapult;
extern motor Rightback;
extern motor LeftBack;
extern motor RightFront;
extern motor LeftFront;
extern motor Intake;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );